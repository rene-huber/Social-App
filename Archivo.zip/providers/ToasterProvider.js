'use client'
import { Toaster } from 'react-hot-toast'

const ToasterContext = () => {
    return (
        <div>
            <Toaster />
        </div>
    )
}

export default ToasterContext;