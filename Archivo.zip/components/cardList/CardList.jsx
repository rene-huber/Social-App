import React, { useState, useEffect, useRef } from 'react';
import styles from "./cardList.module.css";
import Card from "../card/Card";

const CardList = ({ initialData, initialPage, cat }) => {
  const [posts, setPosts] = useState(initialData);
  const [page, setPage] = useState(initialPage);
  const [hasMore, setHasMore] = useState(true);
  const loader = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && hasMore) {
        setPage((prevPage) => prevPage + 1);
      }
    }, { threshold: 1 });

    if (loader.current) {
      observer.observe(loader.current);
    }

    return () => {
      if (loader.current) {
        observer.unobserve(loader.current);
      }
    };
  }, [loader, hasMore]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`http://localhost:3000/api/posts?page=${page}&cat=${cat || ""}`);
        if (!res.ok) {
          throw new Error("Failed to fetch");
        }
        const { posts: newPosts, count } = await res.json();
        setPosts((prevPosts) => [...prevPosts, ...newPosts]);
        setHasMore(posts.length < count);
      } catch (error) {
        console.error("Failed to load posts", error);
      }
    };

    fetchData();
  }, [page, cat]);

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Recent Posts</h1>
      <div className={styles.posts}>
        {posts.map((item) => (
          <Card item={item} key={item._id} />
        ))}
      </div>
      <div ref={loader} />
    </div>
  );
};

export default CardList;
